package cs102groupproject;

import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.layout.StackPane;

/**Controller class for the side panel which includes different menus within.
 * @author Gülşen Mercan
 * @date 24/12/2025
 */
public class SidePanelController {
    
    @FXML private StackPane contentArea;

    @FXML private Parent marketView;
    @FXML private Parent storageView;
    @FXML private Parent sessionView;

    /**The market is shown as default view. */
    @FXML
    public void initialize() {
        showMarket(); 
    }

    @FXML
    private void showMarket() {
        marketView.toFront();
    }

    @FXML
    private void showStorage() {
        storageView.toFront();
    }

    @FXML
    private void showSessions() {
        sessionView.toFront();
    }

    /**Incomplete. */
    @FXML
    private void handleCreateSession() {
        OfficeController.openSessionPopupStatic();
    }

    @FXML
    private void handleClose() {
        OfficeController.toggleSidePanelStatic();
    }
}

